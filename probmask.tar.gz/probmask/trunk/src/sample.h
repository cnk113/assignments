




EXTERN int **sampleFlags;
EXTERN int do_sample;
EXTERN int Nsamples;
void initSampling(int dummy);
