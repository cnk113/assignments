
void initWeighting(char *inFile);

EXTERN PhyloTree *qtree;
EXTERN PhyloTree **leaves;
EXTERN PhyloTree **vlist;
EXTERN int Nodes;
EXTERN double **pairWeights;

